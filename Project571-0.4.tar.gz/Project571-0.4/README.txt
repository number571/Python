
====================================================
MAIN.py - main file (bundle of programs)
HEAD.py - additional functions 
TERM.py - commands functions
====================================================
STNR.py - programs steganography:
 / zip - archive in a file
 / message - write byte-level message
 / read_bytes - read byte-level message
SCAN.py - programs scanners:
 / scanner - port scanner
MLWR.py - programs malware:
 / pyvirus - python virus for python scripts
 / crypter - encrypter files in directory
 / locker - lock screen
 / cryptlocker - locker + crypter
CRPT.py - programs cryptography:
 / cryptanalysis - character frequency
 / replace - replace cipher
 / homophonic - homophonic cipher
 / caesar - caesar cipher
 / rsa - rsa cipher
 / aes - aes cipher
 / vishener - vishener cipher
BRFR.py - programs bruteforce:
 / rockyou - download dictionary rockyou.txt
 / caesar - bruteforce cipher caesar
 / ssh - bruteforce ssh connection
BOTS.py - programs bots:
 / parser - parse sites
 / clicker - autoclicker/automoves/autowrite program
====================================================
